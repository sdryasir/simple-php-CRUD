<?php 
include "./config/config.php";
$id = $_GET['id'];
$query = "SELECT * FROM `user` WHERE `id`=$id";
$result = mysqli_query($con, $query);
$row = mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    if(isset($_SESSION['msg'])){
        echo $_SESSION['msg'];
        unset($_SESSION['msg']);
    }?>
    <form action="process.php?page=edit&id=<?php echo $row['id']?>" method="post">
        <input type="text" value="<?php echo $row['fullname']?>" name="fullname">
        <input type="text" value="<?php echo $row['address']?>" name="address">
        <input type="submit" value="Update" name="btn_submit">
    </form>
</body>
</html>