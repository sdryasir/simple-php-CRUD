<?php
session_start();
$host= "localhost";
$user = "root";
$pass = "";
$db_name = "crud";
$con = mysqli_connect($host, $user, $pass, $db_name) or die()
?>