<?php
include "./config/config.php";
if(isset($_GET['action']))
{
    $action = $_GET['action'];
}
if(isset($_GET['page']))
{
    $page = $_GET['page'];
}
if(isset($_GET['id']))
{
    $id = $_GET['id'];
}
if(isset($_POST['btn_submit']) && $page =='main')
{
    $fullname = htmlspecialchars(trim($_POST['fullname']));
    $address = htmlspecialchars(trim($_POST['address']));

    $qry = "INSERT INTO `user` (`id`, `fullname`, `address`) VALUES (NULL, '$fullname', '$address');";
    $status = mysqli_query($con, $qry);
    if($status){
        $_SESSION['msg'] = "Record has been saved";
        header('Location: index.php');
    }else{
        $_SESSION['msg'] = "Something went wrong";
        header('Location: index.php');
    }
}
if(isset($_POST['btn_submit']) && $page =='edit')
{
    
    $fullname = htmlspecialchars(trim($_POST['fullname']));
    $address = htmlspecialchars(trim($_POST['address']));
    $qry = "UPDATE `user` SET `fullname` = ' $fullname', `address` = '$address' WHERE `user`.`id` = $id;";
    
    $status = mysqli_query($con, $qry);
    if($status){
        $_SESSION['msg'] = "Record has been Updated";
        header('Location: index.php');
    }else{
        $_SESSION['msg'] = "Something went wrong";
        header('Location: index.php');
    }
}
if(isset($action) && $action == 'delete'){
    $del_qry = "DELETE FROM `user` WHERE `user`.`id` = $id";
    $status = mysqli_query($con, $del_qry);
    if($status){
        $_SESSION['msg'] = "Record has been Deleted";
        header('Location: index.php');
    }else{
        $_SESSION['msg'] = "Something went wrong";
        header('Location: index.php');
    }
}

if(isset($action) && $action == 'edit'){
    echo "Edit";
    echo "<br>";
    echo $id;
}
?>