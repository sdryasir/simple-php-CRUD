<?php 
include "./config/config.php";
$query = "SELECT * FROM `user`";
$result = mysqli_query($con, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    if(isset($_SESSION['msg'])){
        echo $_SESSION['msg'];
        unset($_SESSION['msg']);
    }?>
    <form action="process.php?page=main" method="post">
        <input type="text" name="fullname">
        <input type="text" name="address">
        <input type="submit" name="btn_submit">
    </form>
    <table border="1">
        <tr>
            <td>ID</td>
            <td>Full Name</td>
            <td>Address</td>
            <td colspan="2">Actions</td>
        </tr>
        <?php while($row = mysqli_fetch_array($result)){?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['fullname']; ?></td>
                <td><?php echo $row['address']; ?></td>
                <td><a onclick="return confirm('Are you sure to delete this record');" href="process.php?action=delete&id=<?php echo $row['id'];?>">delete</a></td>
                 <td><a href="edit.php?id=<?php echo $row['id'];?>">Edit</a></td>
            </tr>
        <?php }?>
    </table>
</body>
</html>